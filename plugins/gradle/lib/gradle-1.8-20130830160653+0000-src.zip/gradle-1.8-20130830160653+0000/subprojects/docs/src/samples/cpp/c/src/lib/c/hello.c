#include <stdio.h>
#include "hello.h"

void LIB_FUNC hello () {
  printf("Hello world!");
}
