
/**
 * These are the shared classes.
 */
package org.gradle.shared;
