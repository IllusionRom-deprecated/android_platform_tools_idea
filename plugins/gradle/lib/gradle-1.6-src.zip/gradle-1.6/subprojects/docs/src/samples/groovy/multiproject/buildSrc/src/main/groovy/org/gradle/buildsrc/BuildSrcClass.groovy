package org.gradle.buildsrc

import groovy.util.AntBuilder

class BuildSrcClass {

}