package org.gradle;
public class OkTest {
   /** 
    * @testng.test 
    */
   public void passingTest() { }
}
