package org.gradle;
public class Ok{
 String test = "dummy";
}
