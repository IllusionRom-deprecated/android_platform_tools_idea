package org.gradle.services.shared;

import org.gradle.shared.Person;

public class TestTest {
    private String name;

    public void method() {
        new Person("someName");
    }

}
